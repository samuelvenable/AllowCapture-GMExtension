#include <unordered_map>
#include <string>
#include <vector>
#include <SDL3/SDL.h>
#include <SDL3/SDL_video.h>
#include <windows.h>
#define EXPORTED_FUNCTION extern "C" __declspec(dllexport)
#if defined(_MSC_VER)
#if !defined(_WIN64)
#pragma comment(lib, __FILE__"\\..\\SDL3\\lib\\x86\\SDL3.lib")
#elif defined(_WIN64)
#pragma comment(lib, __FILE__"\\..\\SDL3\\lib\\x64\\SDL3.lib")
#endif
#endif

typedef std::unordered_map<double, SDL_Window   *>   WindowStream;
typedef std::unordered_map<double, SDL_Renderer *> WindowRenderer;
typedef std::unordered_map<double, SDL_Surface  *>  WindowSurface;
typedef std::unordered_map<double, SDL_Texture  *>  WindowTexture;
WindowStream     WindowStreamMap;
WindowRenderer WindowRendererMap;
WindowSurface   WindowSurfaceMap;
WindowTexture   WindowTextureMap;
double WindowMapIndex       = -1;

namespace {

  HHOOK g_hWindowHook = nullptr;
  HHOOK g_hMouseHook  = nullptr;
  HWND g_hSourceWnd   = nullptr;
  HWND g_hTargetWnd   = nullptr;

  LRESULT CALLBACK WindowProc(int nCode, WPARAM wParam, LPARAM lParam) {;
    if (nCode == HC_ACTION) {
      CWPSTRUCT *pCwp = reinterpret_cast<CWPSTRUCT *>(lParam);
      if (pCwp->hwnd == g_hSourceWnd && g_hTargetWnd) {
        PostMessageW(g_hTargetWnd, pCwp->message, pCwp->wParam, pCwp->lParam);
      }
    }
    return CallNextHookEx(g_hWindowHook, nCode, wParam, lParam);
  }

  LRESULT CALLBACK MouseProc(int nCode, WPARAM wParam, LPARAM lParam) {;
    if (nCode == HC_ACTION) {
      MSLLHOOKSTRUCT *pMouseStruct = (MSLLHOOKSTRUCT *)lParam;
      if (pMouseStruct && g_hTargetWnd) {
        switch (wParam) {
        case WM_LBUTTONDOWN:
          PostMessageW(g_hTargetWnd, WM_LBUTTONDOWN, wParam, lParam);
          break;
        case WM_LBUTTONUP:
          PostMessageW(g_hTargetWnd, WM_LBUTTONUP, wParam, lParam);
          break;
        case WM_RBUTTONDOWN:
          PostMessageW(g_hTargetWnd, WM_RBUTTONDOWN, wParam, lParam);
          break;
        case WM_RBUTTONUP:
          PostMessageW(g_hTargetWnd, WM_RBUTTONUP, wParam, lParam);
          break;
        case WM_MBUTTONDOWN:
          PostMessageW(g_hTargetWnd, WM_MBUTTONDOWN, wParam, lParam);
          break;
        case WM_MBUTTONUP:
          PostMessageW(g_hTargetWnd, WM_MBUTTONUP, wParam, lParam);
          break;
        case WM_MOUSEMOVE:
          PostMessageW(g_hTargetWnd, WM_MOUSEMOVE, wParam, lParam);
          break;
        case WM_MOUSEWHEEL:
          PostMessageW(g_hTargetWnd, WM_MOUSEWHEEL, wParam, lParam);
          break;
        case WM_MOUSEHOVER:
          PostMessageW(g_hTargetWnd, WM_MOUSEHOVER, wParam, lParam);
          break;
        case WM_MOUSELEAVE:
          PostMessageW(g_hTargetWnd, WM_MOUSELEAVE, wParam, lParam);
          break;
        case WM_MOUSEACTIVATE:
          PostMessageW(g_hTargetWnd, WM_MOUSEACTIVATE, wParam, lParam);
          break;
        case WM_NCMOUSEHOVER:
          PostMessageW(g_hTargetWnd, WM_NCMOUSEHOVER, wParam, lParam);
          break;
        case WM_NCMOUSELEAVE:
          PostMessageW(g_hTargetWnd, WM_NCMOUSELEAVE, wParam, lParam);
          break;
        case WM_NCMOUSEMOVE:
          PostMessageW(g_hTargetWnd, WM_NCMOUSEMOVE, wParam, lParam);
          break;
        case WM_NCHITTEST:
          PostMessageW(g_hTargetWnd, WM_NCHITTEST, wParam, lParam);
          break;
        case WM_NCLBUTTONDOWN:
          PostMessageW(g_hTargetWnd, WM_NCLBUTTONDOWN, wParam, lParam);
          break;
        case WM_NCLBUTTONUP:
          PostMessageW(g_hTargetWnd, WM_NCLBUTTONUP, wParam, lParam);
          break;
        }
      }
    }
    return CallNextHookEx(g_hMouseHook, nCode, wParam, lParam);
  }


  SDL_Surface *SDL_CreateRGBSurfaceFrom(void *pixels, int width, int height, int depth, int pitch, Uint32 Rmask, Uint32 Gmask, Uint32 Bmask, Uint32 Amask) {
    return SDL_CreateSurfaceFrom(width, height, SDL_GetPixelFormatForMasks(depth, Rmask, Gmask, Bmask, Amask), pixels, pitch);
  }

} // anonymouse namespace

EXPORTED_FUNCTION double WindowCreate(const char *Title, unsigned char *Buffer, double Width, double Height) {
  SDL_SetHint(SDL_HINT_RENDER_DRIVER, "software");;
  SDL_Init(SDL_INIT_VIDEO);
  WindowMapIndex++;
  WindowStreamMap[WindowMapIndex] = SDL_CreateWindow(Title, (int)Width, (int)Height, 0);
  if (WindowStreamMap[WindowMapIndex]) {
    WindowRendererMap[WindowMapIndex] = SDL_CreateRenderer(WindowStreamMap[WindowMapIndex], nullptr);
    if (!WindowRendererMap[WindowMapIndex])
      return -1;
    SDL_SetRenderDrawColor(WindowRendererMap[WindowMapIndex], 255, 255, 255, 255);
    SDL_RenderClear(WindowRendererMap[WindowMapIndex]);
    WindowSurfaceMap[WindowMapIndex] = SDL_CreateRGBSurfaceFrom((void *)Buffer, (int)Width, (int)Height, 32, (int)Width * 4, 0x000000ff, 0x0000ff00, 0x00ff0000, 0xff000000);
    if (WindowSurfaceMap[WindowMapIndex]) {
      WindowTextureMap[WindowMapIndex] = SDL_CreateTextureFromSurface(WindowRendererMap[WindowMapIndex], WindowSurfaceMap[WindowMapIndex]);
      SDL_RenderTexture(WindowRendererMap[WindowMapIndex], WindowTextureMap[WindowMapIndex], nullptr, nullptr);
      SDL_RenderPresent(WindowRendererMap[WindowMapIndex]);
      return WindowMapIndex;
    }
  }
  return -1;
}

EXPORTED_FUNCTION double WindowUpdate(double WindowIndex, unsigned char *Buffer, double Width, double Height) {
  if (WindowStreamMap.find(WindowIndex) == WindowStreamMap.end()) 
    return 0;
  SDL_DestroyTexture(WindowTextureMap[WindowIndex]);
  SDL_DestroySurface(WindowSurfaceMap[WindowIndex]);
  WindowTextureMap.erase(WindowIndex);
  WindowSurfaceMap.erase(WindowIndex);
  SDL_SetRenderDrawColor(WindowRendererMap[WindowIndex], 255, 255, 255, 255);
  SDL_RenderClear(WindowRendererMap[WindowIndex]);
  WindowSurfaceMap[WindowIndex] = SDL_CreateRGBSurfaceFrom((void *)Buffer, (int)Width, (int)Height, 32, (int)Width * 4, 0x000000ff, 0x0000ff00, 0x00ff0000, 0xff000000);
  if (WindowSurfaceMap[WindowIndex]) {
    WindowTextureMap[WindowIndex] = SDL_CreateTextureFromSurface(WindowRendererMap[WindowIndex], WindowSurfaceMap[WindowIndex]);
    SDL_RenderTexture(WindowRendererMap[WindowIndex], WindowTextureMap[WindowIndex], nullptr, nullptr);
    SDL_RenderPresent(WindowRendererMap[WindowIndex]);
    return 1;
  }
  return 0;
}

EXPORTED_FUNCTION double WindowDestroy(double WindowIndex) {
  if (WindowStreamMap.find(WindowIndex) == WindowStreamMap.end()) 
    return 0;
  SDL_DestroyTexture(WindowTextureMap[WindowIndex]);
  SDL_DestroySurface(WindowSurfaceMap[WindowIndex]);
  SDL_DestroyRenderer(WindowRendererMap[WindowIndex]);
  SDL_DestroyWindow(WindowStreamMap[WindowIndex]);
  WindowTextureMap.erase(WindowIndex);
  WindowSurfaceMap.erase(WindowIndex);
  WindowRendererMap.erase(WindowIndex);
  WindowStreamMap.erase(WindowIndex);
  return 1;
}

EXPORTED_FUNCTION double WindowGetCloseButton() {
  SDL_PumpEvents();
  SDL_Event Event;
  SDL_PollEvent(&Event);
  if (Event.type >= SDL_EVENT_WINDOW_FIRST && Event.type <= SDL_EVENT_WINDOW_LAST &&
    Event.type == SDL_EVENT_WINDOW_CLOSE_REQUESTED) {
    for (auto it = WindowStreamMap.begin(); it != WindowStreamMap.end(); ++it)
      if (it->second == SDL_GetWindowFromID(Event.window.windowID))
        return it->first;
  }
  return -1;
}

EXPORTED_FUNCTION void WindowSetParentWindow(double WindowIndex, void *ParentHandle) {
  SDL_PropertiesID propsId = SDL_GetWindowProperties(WindowStreamMap[WindowIndex]);
  if (!propsId) return;
  HWND hWnd = (HWND)SDL_GetPointerProperty(propsId, SDL_PROP_WINDOW_WIN32_HWND_POINTER, nullptr);
  if (!hWnd) return;
  RECT parentFrame; GetClientRect((HWND)ParentHandle, &parentFrame);
  int parentFrameWidth = parentFrame.right - parentFrame.left;
  int parentFrameHeight = parentFrame.bottom - parentFrame.top;
  if (!g_hWindowHook) SetParent(hWnd, (HWND)(void *)ParentHandle);
  SetWindowLongPtrW((HWND)(void *)ParentHandle, GWL_STYLE, 
  GetWindowLongPtrW((HWND)(void *)ParentHandle, GWL_STYLE) | WS_CLIPCHILDREN | WS_CLIPSIBLINGS);
  SetWindowLongPtrW(hWnd, GWL_STYLE, (GetWindowLongPtrW(hWnd, GWL_STYLE) | WS_POPUP) & ~WS_CAPTION);
  MoveWindow(hWnd, 0, 0, parentFrameWidth, parentFrameHeight, TRUE);
  g_hSourceWnd = hWnd; g_hTargetWnd = (HWND)(void *)ParentHandle;
  DWORD threadId = GetWindowThreadProcessId(g_hTargetWnd, nullptr);
  if (!g_hWindowHook) g_hWindowHook = SetWindowsHookExW(WH_CALLWNDPROC, WindowProc, nullptr, threadId);
  if (!g_hMouseHook)  g_hMouseHook  = SetWindowsHookExW(WH_MOUSE, MouseProc, nullptr, threadId);
}
